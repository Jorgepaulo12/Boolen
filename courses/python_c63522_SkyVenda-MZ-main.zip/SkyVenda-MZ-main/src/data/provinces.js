export const PROVINCIAS = [
    'Niassa',
    'Cabo Delgado',
    'Nampula',
    'Zambézia',
    'Tete',
    'Sofala',
    'Manica',
    'Inhambane',
    'Gaza',
    'Maputo Província',
    'Maputo Cidade',
  ];