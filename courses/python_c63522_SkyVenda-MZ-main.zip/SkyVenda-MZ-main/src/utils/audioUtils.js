// Utilitários para processamento de áudio

// Cache para guardar durações já carregadas
const audioDurationCache = new Map();

/**
 * Obtém a duração de um arquivo de áudio de uma URL
 * @param {string} url - A URL do arquivo de áudio
 * @returns {Promise<number>} Uma promessa que resolve para a duração em segundos
 */
export const getAudioDuration = (url) => {
  return new Promise((resolve) => {
    // Verificar se já temos essa duração no cache
    if (audioDurationCache.has(url)) {
      return resolve(audioDurationCache.get(url));
    }

    // Criar um elemento de áudio temporário
    const audio = new Audio();
    
    // Definir um timeout para não esperar infinitamente
    const timeoutId = setTimeout(() => {
      // Se demorar muito, retorna 0 mas continua carregando em segundo plano
      resolve(0);
    }, 3000); // 3 segundos de timeout
    
    // Quando os metadados forem carregados, resolver a promessa
    audio.addEventListener('loadedmetadata', () => {
      clearTimeout(timeoutId);
      
      if (isFinite(audio.duration) && !isNaN(audio.duration)) {
        audioDurationCache.set(url, audio.duration);
        resolve(audio.duration);
      } else {
        audioDurationCache.set(url, 0);
        resolve(0);
      }
    });
    
    // Caso haja erro, resolver como 0
    audio.addEventListener('error', () => {
      clearTimeout(timeoutId);
      audioDurationCache.set(url, 0);
      resolve(0);
    });
    
    // Iniciar carregamento dos metadados
    audio.preload = 'metadata';
    audio.src = url;
    audio.load();
  });
};

/**
 * Pré-carrega metadados de múltiplos áudios em segundo plano
 * @param {Array<{url: string, id: string}>} audioList - Lista de áudios para pré-carregar
 * @param {Function} onDurationLoaded - Callback chamado quando a duração for carregada
 */
export const preloadAudioMetadata = (audioList, onDurationLoaded) => {
  if (!audioList || !Array.isArray(audioList) || audioList.length === 0) return;
  
  audioList.forEach(item => {
    if (!item.url) return;
    
    // Se já temos no cache, retorna imediatamente
    if (audioDurationCache.has(item.url)) {
      onDurationLoaded && onDurationLoaded(item.id, audioDurationCache.get(item.url));
      return;
    }
    
    // Carrega em segundo plano
    getAudioDuration(item.url).then(duration => {
      onDurationLoaded && onDurationLoaded(item.id, duration);
    });
  });
};

/**
 * Formata a duração em segundos para o formato MM:SS
 * @param {number} seconds - Duração em segundos
 * @returns {string} Duração formatada
 */
export const formatAudioDuration = (seconds) => {
  if (!seconds || isNaN(seconds) || !isFinite(seconds)) {
    return '0:00';
  }
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
};
