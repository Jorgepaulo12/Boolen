import React, { createContext, useState, useContext, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import api from '../api/api_fecher';
import FullScreenLoader from '../components/loaders/FullScreenLoader';

export const AuthContext = createContext(null);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [token, setToken] = useState(localStorage.getItem('auth_token') || null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [webSocketConnected, setWebSocketConnected] = useState(false);
  
  const wsRef = useRef(null);
  const navigate = useNavigate();

  // Função para conectar ao WebSocket
  const connectWebSocket = () => {
    if (wsRef.current) {
      wsRef.current.close(); // Fecha a conexão antiga, se existir
    }

    wsRef.current = new WebSocket(`ws://192.168.1.63:8000/ws?token=${token}`);

    wsRef.current.onopen = () => {
      setWebSocketConnected(true);
      console.log('WebSocket conectado');
    };

    wsRef.current.onmessage = (event) => {
      const data = JSON.parse(event.data);
      if (data.type === "notification") {
        toast.info(data.data.message);
      }
    };

    wsRef.current.onclose = () => {
      console.log('WebSocket desconectado');
      setWebSocketConnected(false);
      setTimeout(() => {
        if (isAuthenticated) {
          connectWebSocket();
        }
      }, 5000); // Tenta reconectar após 5 segundos
    };
  };

  // Função para reconectar o WebSocket
  const reconnectWebSocket = () => {
    if (!webSocketConnected && user?.id) {
      connectWebSocket();
    }
  };

  // Função para obter o token
  const getToken = async (username, password) => {
    const formData = new FormData();
    formData.append('username', username);
    formData.append('password', password);
    try {
      const response = await api.post('/usuario/token', formData);
      const token = response.data.access_token;
      localStorage.setItem("auth_token", token);
      localStorage.setItem("user_id", response.data.id);
      
      setToken(token);
      const userResponse = await api.get("/usuario/user", {
        headers: { Authorization: `Bearer ${token}` }
      });
      setUser(userResponse.data);
      setIsAuthenticated(true);

      connectWebSocket();
    } catch (error) {
      if (error.message === "Network Error") {
        toast.error("Verifique a sua ligação");
      } else if (error.message === "Request failed with status code 401") {
        toast.error("Username ou palavra-passe incorreta");
      } else {
        toast.error("Erro desconhecido");
      }
    }
  };

  // Função de logout
  const logout = () => {
    if (wsRef.current) {
      wsRef.current.close();
      wsRef.current = null;
    }
    localStorage.removeItem('auth_token');
    localStorage.removeItem('user_id');
    setToken(null);
    setUser(null);
    setIsAuthenticated(false);
    setWebSocketConnected(false);
    navigate('/login');
  };

  // Função de cadastro
  const signup = async (name, email, username, password) => {
    const formData = new FormData();
    formData.append('nome', name);
    formData.append('email', email);
    formData.append('username', username);
    formData.append('senha', password);
    formData.append('tipo', 'nhonguista');

    try {
      const res = await api.post('/usuario/cadastro', formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });

      if (res.status === 200 || res.status === 201) {
        toast.success("Cadastrado com sucesso");
        navigate('/login');
      }
    } catch (error) {
      if (error.message === "Network Error") {
        toast.error("Verifique a Ligação");
      } else {
        toast.error("Falha no cadastro. Tente novamente.");
      }
    }
  };

  // Recupera o usuário e tenta manter a conexão WebSocket
  useEffect(() => {
    const fetchUser = async () => {
      if (token) {
        try {
          const response = await api.get("/usuario/user", {
            headers: { Authorization: `Bearer ${token}` }
          });
          setUser(response.data);
          setIsAuthenticated(true);
          
          const userId = localStorage.getItem('user_id');
          if (userId && response.data.username) {
            connectWebSocket();
          }
        } catch (error) {
          if (error.message === "Network Error") {
            toast.error("Verifique a sua ligação");
          } else if (error.status === 401) {
            logout();
          } else {
            toast.error("Erro desconhecido");
          }
        }
      }
      setLoading(false);
    };

    fetchUser();
  }, [token]);

  // Redireciona para a página inicial após o login
  useEffect(() => {
    if (!loading && isAuthenticated && user && window.location.pathname === '/login') {
      navigate('/');
    }
  }, [isAuthenticated, user, loading, navigate]);

  // Verifica se a conexão WebSocket está ativa a cada 10 segundos
  useEffect(() => {
    const intervalId = setInterval(() => {
      reconnectWebSocket();
    }, 10000); // Checa a cada 10 segundos

    return () => clearInterval(intervalId); // Limpa o intervalo quando o componente for desmontado
  }, [webSocketConnected, user]);

  // Limpa a conexão WebSocket ao desmontar
  useEffect(() => {
    return () => {
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, []);

  // Exibe o loader enquanto a autenticação é verificada
  if (loading) {
    return <FullScreenLoader />;
  }

  return (
    <AuthContext.Provider value={{ 
      user, 
      loading,
      setLoading,  
      logout,
      signup, 
      token, 
      setUser,
      getToken, 
      setToken, 
      isAuthenticated,
      ws: wsRef.current,
      webSocketConnected,
      reconnectWebSocket
    }}>
      {children}
    </AuthContext.Provider>
  );
};
