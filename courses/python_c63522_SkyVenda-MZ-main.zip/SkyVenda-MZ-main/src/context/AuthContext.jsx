import React, { createContext, useContext, useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../api/api';
import toast from 'react-hot-toast';
import FullScreenLoader from '../components/loaders/FullScreenLoader';

export const AuthContext = createContext(null);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [token, setToken] = useState(localStorage.getItem('auth_token') || null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  
  const navigate = useNavigate();

  // Função para obter o token
  const getToken = async (username, password) => {
    const formData = new FormData();
    formData.append('username', username);
    formData.append('password', password);
    try {
      const response = await api.post('/usuario/token', formData);
      const token = response.data.access_token;
      localStorage.setItem("auth_token", token);
      localStorage.setItem("user_id", response.data.id);
      
      setToken(token);
      const userResponse = await api.get("/usuario/user", {
        headers: { Authorization: `Bearer ${token}` }
      });
      setUser(userResponse.data);
      setIsAuthenticated(true);
    } catch (error) {
      if (error.message === "Network Error") {
        toast.error("Verifique a sua ligação");
      } else if (error.message === "Request failed with status code 401") {
        toast.error("Username ou palavra-passe incorreta");
      } else {
        toast.error("Erro desconhecido");
      }
    }
  };

  // Função de logout
  const logout = () => {
    localStorage.removeItem('auth_token');
    localStorage.removeItem('user_id');
    setToken(null);
    setUser(null);
    setIsAuthenticated(false);
    navigate('/login');
  };

  // Função de cadastro
  const signup = async (name, email, username, password) => {
    const formData = new FormData();
    formData.append('nome', name);
    formData.append('email', email);
    formData.append('username', username);
    formData.append('senha', password);
    formData.append('tipo', 'nhonguista');

    try {
      const res = await api.post('/usuario/cadastro', formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });

      if (res.status === 200 || res.status === 201) {
        toast.success("Cadastrado com sucesso");
        navigate('/login');
      }
    } catch (error) {
      if (error.message === "Network Error") {
        toast.error("Verifique a Ligação");
      } else {
        toast.error("Falha no cadastro. Tente novamente.");
      }
    }
  };

  // Recupera o usuário
  useEffect(() => {
    const fetchUser = async () => {
      if (token) {
        try {
          const response = await api.get("/usuario/user", {
            headers: { Authorization: `Bearer ${token}` }
          });
          setUser(response.data);
          setIsAuthenticated(true);
        } catch (error) {
          if (error.message === "Network Error") {
            toast.error("Verifique a sua ligação");
          } else if (error.status === 401) {
            logout();
          } else {
            toast.error("Erro desconhecido");
          }
        }
      }
      setLoading(false);
    };

    fetchUser();
  }, [token]);

  // Redireciona para a página inicial após o login
  useEffect(() => {
    if (!loading && isAuthenticated && user && window.location.pathname === '/login') {
      navigate('/');
    }
  }, [isAuthenticated, user, loading, navigate]);

  // Exibe o loader enquanto a autenticação é verificada
  if (loading) {
    return <FullScreenLoader />;
  }

  return (
    <AuthContext.Provider value={{ 
      user, 
      loading,
      setLoading,  
      logout,
      signup, 
      token, 
      setUser,
      getToken, 
      setToken, 
      isAuthenticated
    }}>
      {children}
    </AuthContext.Provider>
  );
};
