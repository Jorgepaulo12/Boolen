import React, { createContext, useContext, useEffect, useState, useCallback } from "react";
import { useAuth } from "./AuthContext";
import { base_url } from "../api/api";

const WebSocketContext = createContext(null);

// Ensure proper protocol conversion by using replace with full protocol strings
const WS_URL = base_url.replace('http://', 'ws://').replace('https://', 'wss://');

export const WebSocketProvider = ({ children }) => {
  const [socket, setSocket] = useState(null);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [webSocketConnected, setWebSocketConnected] = useState(false);
  const [isReconnecting, setIsReconnecting] = useState(false);
  const { token, isAuthenticated } = useAuth();

  const connectWebSocket = useCallback(() => {
    // Não tentar conectar se já estiver conectado ou em processo de reconexão
    if (webSocketConnected || isReconnecting || !isAuthenticated || !token || !isOnline) return;

    setIsReconnecting(true);
    const ws = new WebSocket(`${WS_URL}/ws?token=${token}`);

    ws.onopen = () => {
      console.log("WebSocket conectado!");
      setWebSocketConnected(true);
      setIsReconnecting(false);
    };

    ws.onmessage = (event) => console.log("Mensagem recebida:", event.data);

    ws.onerror = (error) => {
      console.error("Erro WebSocket:", error);
      setWebSocketConnected(false);
    };

    ws.onclose = () => {
      console.log("WebSocket desconectado!");
      setWebSocketConnected(false);
      if (isOnline && isAuthenticated) {
        console.log("Tentando reconectar em 10 segundos...");
        setTimeout(() => {
          setIsReconnecting(false);
          connectWebSocket();
        }, 10000); // 10 segundos entre tentativas
      }
    };

    setSocket(ws);
    return ws;
  }, [token, isAuthenticated, isOnline, webSocketConnected, isReconnecting]);

  useEffect(() => {
    const handleOnline = () => {
      console.log("Conexão de internet restaurada");
      setIsOnline(true);
      if (!webSocketConnected) {
        connectWebSocket();
      }
    };

    const handleOffline = () => {
      console.log("Conexão de internet perdida");
      setIsOnline(false);
      if (socket) {
        socket.close();
        setSocket(null);
        setWebSocketConnected(false);
      }
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Iniciar conexão WebSocket se estiver online
    let ws = null;
    if (isOnline && !webSocketConnected) {
      ws = connectWebSocket();
    }

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      if (ws) {
        ws.close();
        setWebSocketConnected(false);
        console.log("WebSocket fechado!");
      }
    };
  }, [connectWebSocket, socket, webSocketConnected]);

  const contextValue = {
    socket,
    isOnline,
    webSocketConnected,
    reconnect: connectWebSocket
  };

  return (
    <WebSocketContext.Provider value={contextValue}>
      {children}
    </WebSocketContext.Provider>
  );
};

export const useWebSocket = () => useContext(WebSocketContext);
