import React from 'react'

export default function PedidoContainer() {
  return (
    <div className="p-4">
        <div className="bg-white rounded-lg shadow h-[calc(100vh-100px)]">
          <div className="p-4 border-b">
            <h2 className="text-lg font-semibold text-gray-900">Meus Pedidos</h2>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 p-4">
           
          </div>
        </div>
    </div>
  )
}
