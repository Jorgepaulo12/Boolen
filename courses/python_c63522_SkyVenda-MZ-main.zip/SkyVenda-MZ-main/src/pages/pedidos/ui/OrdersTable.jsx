import React from 'react';
import { AlertCircle, Eye } from 'lucide-react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { OrderStatus } from './OrderStatus';
import { formatCurrency } from '../../../lib/utils';
import { Link } from 'react-router-dom';
import { base_url } from '../../../api/api';

export const OrdersTable = ({ orders, onAcceptOrder, onRejectOrder,loadingAccept,onCancel,loadingCancel }) => {
  if (orders.length === 0) {
    return (
      <div className="text-center py-8">
        <AlertCircle className="mx-auto h-12 w-12 text-gray-400" />
        <h3 className="mt-2 text-sm font-semibold text-gray-900">Nenhum pedido encontrado</h3>
        <p className="mt-1 text-sm text-gray-500">
          Não existem pedidos que correspondam aos critérios de busca.
        </p>
      </div>
    );
  }

  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Produto</TableHead>
          <TableHead>Data</TableHead>
          <TableHead>Vendedor</TableHead>
          <TableHead>Comprador</TableHead>
          <TableHead>Quantidade</TableHead>
          <TableHead>Total</TableHead>
          <TableHead>Status</TableHead>
          <TableHead>Ações</TableHead>
          <TableHead>Detalhes</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {orders.map((order) => (
          <TableRow key={order.id}>
            <TableCell>
              <img
                src={`https://skyvendamz.up.railway.app/produto/${order.foto_capa}`}
                alt="Produto"
                onError={(e) => e.target.src = `${base_url}/default.png`}
                className="w-12 h-12 rounded-md object-cover"
              />
            </TableCell>
            <TableCell>
              {new Date(order.data_pedido).toLocaleDateString('pt-BR')}
            </TableCell>
            <TableCell>{order.nome_vendedor}</TableCell>
            <TableCell>{order.nome_comprador}</TableCell>
            <TableCell>{order.quantidade}</TableCell>
            <TableCell>{formatCurrency(order.preco_total)}</TableCell>
            <TableCell>
              <OrderStatus order={order} />
            </TableCell>
            <TableCell>
                {order.status === "pendente" && !order.aceito_pelo_vendedor && (
                  <div className="flex space-x-2">
                    {order?.compra ? (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => onCancel(order.id)}
                        className="bg-red-50 text-red-700 hover:bg-red-100"
                      >
                        {!loadingCancel ? <>Cancelar o pedido</> : <>processando...</>}
                      </Button>
                    ) : (
                      <>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => onAcceptOrder(order.id)}
                          className="bg-green-50 text-green-700 hover:bg-green-100"
                        >
                          {!loadingAccept ? <>Aceitar</> : <>Processando...</>}
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => onRejectOrder(order.id)}
                          className="bg-orange-50 text-orange-700 hover:bg-orange-100"
                        >
                          Rejeitar
                        </Button>
                      </>
                    )}
                  </div>
                )}
                {order.status === "cancelado" && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => onDeleteOrder(order.id)}
                    className="bg-red-50 text-red-700 hover:bg-red-100"
                  >
                    Deletar o pedido
                  </Button>
                )}
              </TableCell>
            <TableCell>
              <Link to={`/pedido/${order.id}`}>
              <Eye className="h-5 w-5" />
              </Link>
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
};