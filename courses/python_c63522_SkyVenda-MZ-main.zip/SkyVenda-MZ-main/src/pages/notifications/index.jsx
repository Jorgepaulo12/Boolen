import React from 'react'

export default function Notificacoes() {
  return (
    <div>Notificacoes</div>
  )
}
