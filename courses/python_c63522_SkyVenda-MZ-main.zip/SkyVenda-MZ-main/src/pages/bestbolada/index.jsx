import React from 'react'

export default function BestBolada() {
  return (
    <div>
        ooo
    </div>
  )
}
