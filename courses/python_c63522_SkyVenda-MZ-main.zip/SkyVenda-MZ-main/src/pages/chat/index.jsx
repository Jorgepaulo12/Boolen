import React, { useEffect, useState, useRef, useCallback } from 'react';
import { useAuth } from '../../context/AuthContext';
import { 
  ArrowLeft, Ban, Edit, Grid, Heart, Info, 
  MessageCirclePlus, Newspaper, Smile, Plus, X, Search,
  ThumbsDown, Trash, 
  Check, Camera, Mic, Image, File, Eye, Music, Pause, Play, ArrowUp,
  Loader,
  Timer, Send
} from 'lucide-react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import { useWebSocket } from '../../context/websoketContext';
import CheckCheck from '../../components/icon/checkcheck';
import { base_url } from '../../api/api';
import MessageItem from './ui/MessageItem';

const API_URL = base_url;

/*



*/
export default function Chat() {
  const { user, token } = useAuth();
  const [selectedUser, setSelectedUser] = useState(null);
  const [messageInput, setMessageInput] = useState('');
  const [chats, setChats] = useState([]);
  const [showUser, setShowUser] = useState(false);
  const [userTyping, setUserTyping] = useState(null);
  const [showOnlineUsers, setShowOnlineUsers] = useState(false);
  const [onlineUsers, setOnlineUsers] = useState([]);
  const [view, setView] = useState('chats');
  const [gettingChats, setGettingChats] = useState(true);
  const [friends, setFriends] = useState([]);
  const [loadingFriends, setLoadingFriends] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [recordingDuration, setRecordingDuration] = useState(0);
  const [mediaPreview, setMediaPreview] = useState(null);
  const [mediaType, setMediaType] = useState(null);
  const [selectedFile, setSelectedFile] = useState(null);
  const [audioStates, setAudioStates] = useState({});
  const [pendingUploads, setPendingUploads] = useState([]);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const mediaInputRef = useRef(null);
  const mediaRecorderRef = useRef(null);
  const audioChunksRef = useRef([]);
  const audioRef = useRef(null);
  const audioContextRef = useRef(null);
  const analyserRef = useRef(null);
  const animationFrameRef = useRef(null);
  const canvasRef = useRef(null);
  const messagesEndRef = useRef(null);
  const {socket} = useWebSocket();

  function getHours(data){
    const datas=new Date(data)
    const horas=datas.getHours()
    const minutos=datas.getMinutes()
    return `${horas}:${minutos}`
  }

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [selectedUser?.mensagens]);


  useEffect(() => {
    fetchChats();
    fetchFriends();
  }, [token]);

  const fetchFriends = async () => {
    setLoadingFriends(true);
    try {
      const response = await axios.get(`${API_URL}/get_friends`, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      setFriends(response.data);
    } catch (error) {
      console.error('Error fetching friends:', error);
    } finally {
      setLoadingFriends(false);
    }
  };

  const fetchChats = async () => {
    setGettingChats(true);
    try {
      const response = await axios.get(`${API_URL}/chats`, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      setChats(response.data);
    } catch (error) {
      console.error('Error fetching chats:', error);
    } finally {
      setGettingChats(false);
    }
  };

  useEffect(() => {
    if (!socket) return;
    
    socket.onmessage = (event) => {
      const data = JSON.parse(event.data);
      
      
      switch(data.type) {
        case 'message':
          // Handle incoming message
          handleIncomingMessage(data.data);
          break;

        case 'typing':
          setUserTyping(data.data.username);
          setTimeout(() => setUserTyping(null), 3000);
          break;
          
        case 'message_status':
          console.log("Mensagem de status recebida:", data.data);
          
          if (!data.data.message_id) {
            console.error("Recebido status de mensagem sem message_id:", data.data);
            break;
          }
          
          // Atualiza a mensagem tanto no usuário selecionado quanto na lista de chats
          updateMessageById(data.data.message_id, msg => ({
            ...msg,
            is_delivered: true,
            // Apenas atualize a URL do arquivo se não existir ou se vier uma nova URL válida
            file_url: data.data.file_url && data.data.file_url.trim() !== '' ? 
                     data.data.file_url : msg.file_url
          }));
          
          console.log("Mensagem específica atualizada:", data.data.message_id);
          break;
      
        case 'notification':
          handleNotification(data.data);
          break;

        default:
          console.log('Unknown message type:', data);
      }
    };
    
    return () => {
      // Clean up if needed
    };
  }, [socket, chats]);

  // Handle incoming messages and update chat list
  const handleIncomingMessage = (messageData) => {
    const { from_user, content } = messageData;
  
    setChats((prevChats) => {
      // Procura o índice do chat que deve receber a mensagem
      const chatIndex = prevChats.findIndex((chat) => chat.id === from_user);
      if (chatIndex !== -1) {
        const chat = prevChats[chatIndex];
        const newMessage = {
          id: Date.now(), // ID temporário
          message_id: messageData.message_id || null,
          sender_id: from_user,
          receiver_id: user.id,
          content: content,
          message_type: messageData.message_type || 'text',
          file_url: messageData.file_url || null,
          file_name: messageData.file_name || null,
          file_size: messageData.file_size || null,
          is_delivered: true,
          reaction: null,
          is_read: false,
          created_at: new Date().toISOString(),
          status: 'pending' // Mantido para compatibilidade com a UI
        };
  
        // Atualiza o chat com a nova mensagem
        const updatedChat = {
          ...chat,
          mensagens: [...chat.mensagens, newMessage],
        };
  
        // Move o chat atualizado para o topo da lista
        const newChats = [
          updatedChat,
          ...prevChats.filter((_, i) => i !== chatIndex),
        ];
  
        // Se esse chat estiver selecionado, atualize também o estado dele
        if (selectedUser && selectedUser.id === from_user) {
          setSelectedUser(updatedChat);
        }
  
        return newChats;
      }
  
      // Se o chat não existir, você pode tratá-lo aqui se necessário
      return prevChats;
    }); 
  };
  

  const handleNotification = (notification) => {
    if (notification.type === 'user_connected') {
      setOnlineUsers(prev => {
        if (!prev.some(user => user.sky_user_id === notification.data.user_id)) {
          return [...prev, notification.data];
        }
        return prev;
      });
    } else if (notification.type === 'user_disconnected') {
      setOnlineUsers(prev => 
        prev.filter(user => user.sky_user_id !== notification.data.user_id)
      );
    }
  };

  const handleUserSelect = (chat) => {
    //chat.mensagens
    console.log(chat.mensagens)
    setSelectedUser(chat);
    setShowOnlineUsers(false);
    setView('messages');
  };

  const handleFriendSelect = (friend) => {
    // Create a new chat object for the friend
    const newChat = {
      id: friend.id,
      nome: friend.nome,
      username: friend.username,
      foto: friend.foto_perfil,
      mensagens: []
    };
    
    setSelectedUser(newChat);
    setShowOnlineUsers(false);
    setView('messages');
  };
  function generateMessageId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2, 5);
  }

  const blobToBase64 = (blob) => {
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result);
      reader.readAsDataURL(blob);
    });
  };

  const handleSendMessageWithFile = () => {
    if (!selectedUser || !mediaPreview) return;

    // Cria a nova mensagem
    const messageId = generateMessageId();
    const newMessage = {
      id: messageId,
      message_id: messageId,
      sender_id: user.id,
      receiver_id: selectedUser.id,
      content: mediaType === 'audio' ? '' : messageInput || '',
      message_type: mediaType,
      file_url: mediaPreview,
      file_name: selectedFile ? selectedFile.name : null,
      file_size: selectedFile ? selectedFile.size : null,
      is_delivered: false,
      reaction: null,
      is_read: false,
      created_at: new Date().toISOString(),
      status: 'uploading' // Mantido apenas para controle de UI durante o upload
    };

    // Atualiza a lista de chats
    setChats((prevChats) => {
      const existingChatIndex = prevChats.findIndex(
        (chat) => chat.id === selectedUser.id
      );

      if (existingChatIndex !== -1) {
        const chat = prevChats[existingChatIndex];
        const updatedChat = {
          ...chat,
          mensagens: [...(chat.mensagens || []), newMessage],
        };
        return [
          updatedChat,
          ...prevChats.filter((_, i) => i !== existingChatIndex),
        ];
      } else {
        return [
          {
            ...selectedUser,
            mensagens: [newMessage],
          },
          ...prevChats,
        ];
      }
    });

    // Atualiza o chat selecionado
    setSelectedUser((prevUser) => ({
      ...prevUser,
      mensagens: [...(prevUser.mensagens || []), newMessage],
    }));

    // Salva o texto da mensagem para uso no upload
    const messageText = mediaType === 'audio' ? '' : messageInput;
    
    // Limpa o input e o preview depois de enviar a mensagem
    setMessageInput('');
    
    // Chama função de upload em segundo plano
    testUpload(selectedFile, messageId, selectedUser.id, messageText);

    // Limpa o preview - mantemos essa parte para limpar o preview imediatamente após enviar
    cancelMedia();

    // Scroll para baixo
    setTimeout(scrollToBottom, 100);
  };

  // Função de teste do upload
  const testUpload = async (file, messageId, selectedUserId, messageText) => {
    try {
      const formData = new FormData();
      
      if (file instanceof Blob || file instanceof File) {
        // For audio files, ensure proper naming and MIME type
        if (file.type.startsWith('audio/')) {
          const extension = file.type.includes('wav') ? 'wav' : 'webm';
          formData.append('file', file, `audio_${Date.now()}.${extension}`);
        } else {
          formData.append('file', file);
        }
      }
      
      formData.append('message_id', messageId);
      formData.append('receiver_id', selectedUserId);
      formData.append('content', messageText || '');

      // Log the FormData contents for debugging
      for (let pair of formData.entries()) {
        console.log(pair[0], pair[1], pair[1] instanceof Blob ? pair[1].type : '');
      }

      const response = await axios.post(
        `${API_URL}/mensagens/enviar`,
        formData,
        {
          headers: {
            'Content-Type': 'multipart/form-data',
            'Authorization': `Bearer ${token}`
          }
        }
      );

      console.log("Resposta do upload:", response.data);
      updateMessageAfterUpload(messageId, response.data);
      sendWebSocketMessageAfterUpload(response.data, messageId, selectedUserId, mediaType, messageText);
      
    } catch (error) {
      console.error("Erro no upload:", error.response?.data || error.message);
      console.error("Detalhes do arquivo:", file.type, file.size);
      updateMessageWithError(messageId);
    }
  };

  const sendWebSocketMessageAfterUpload = (uploadResponse, messageId, receiverId, messageType, content) => {
    const message = {
      type: "message",
      to_user: receiverId,
      message_id: messageId,
      content: content || '', // Texto da mensagem, se houver
      message_type: messageType,
      file_url: uploadResponse.file_url,
      file_name: uploadResponse.file_name || '',
      file_size: uploadResponse.file_size || 0,
      file_type: uploadResponse.file_type,
      file_extension: uploadResponse.file_extension
    };

    try {
      socket.send(JSON.stringify(message));
      console.log("Mensagem websocket enviada após upload:", message);
    } catch (error) {
      console.error("Erro ao enviar mensagem websocket:", error);
    }
  };

  const uploadFile = async (messageId, fileType, fileToUpload = null) => {
    console.log(`uploadFile redirecionando para uploadFileAsync`);
    return uploadFileAsync(messageId, fileType, fileToUpload, selectedUser?.id);
  };

  const uploadFileAsync = async (messageId, fileType, fileToUpload, receiverId) => {
    console.log(`uploadFileAsync INICIADO - mensagem: ${messageId}, tipo: ${fileType}`);
    
    try {
      // Garante que temos todos os dados necessários
      if (!fileToUpload) {
        console.error('Nenhum arquivo para upload');
        return;
      }
      
      if (!receiverId) {
        console.error('Nenhum destinatário especificado');
        return;
      }
      
      let fileData;
      
      // Converter para base64 se necessário
      if (fileToUpload instanceof Blob) {
        console.log("Convertendo Blob para base64");
        fileData = await blobToBase64(fileToUpload);
        console.log("Conversão para base64 concluída:", fileData ? "Sucesso" : "Falha");
      } else {
        console.log("Usando fileToUpload diretamente");
        fileData = fileToUpload;
      }
      
      if (!fileData) {
        console.error('Falha ao preparar arquivo para upload');
        return;
      }
      
      console.log("Preparando FormData para envio");
      // Preparar os dados para envio (conforme exemplo curl)
      const formData = new FormData();
      formData.append('file', fileData); // Arquivo em base64
      formData.append('message_id', messageId);
      formData.append('receiver_id', receiverId);
      
      console.log("Enviando request para API...");
      // Fazer o upload usando axios
      const response = await axios.post(
        `https://skyvendamz.up.railway.app/mensagens/enviar`,
        formData,
        {
          headers: {
            'Content-Type': 'multipart/form-data',
            'Authorization': `Bearer ${token}`
          }
        }
      );
      
      console.log(`Upload concluído para mensagem: ${messageId}`);
      console.log('Resposta do servidor:', response.data);
      
      return response.data;
    } catch (error) {
      console.error('Erro no upload do arquivo:', error);
      console.error('Detalhes do erro:', error.response ? error.response.data : error.message);
    }
  };
  
  const sendAudioMessage = async (audioUrl) => {
    if (!audioUrl || !selectedFile) return;

    try {
      // Instead of trying to handle audio differently, we'll use the same
      // file handling mechanism as for regular files since we now have a File object
      
      // Just call the existing handleSendMessageWithFile function
      // which already knows how to handle files properly
      handleSendMessageWithFile();
      
      // No need for the custom audio handling below since we now use the standard file upload mechanism
      /*
      let audioData;
      if (audioUrl.startsWith('blob:')) {
        const response = await fetch(audioUrl);
        const blob = await response.blob();
        audioData = await blobToBase64(blob);
      } else {
        audioData = audioUrl;
      }

      // Cria o FormData
      const formData = new FormData();
      formData.append('audio', audioData);
      formData.append('message_id', generateMessageId());
      formData.append('receiver_id', selectedUser.id);

      // Envia para a API
      await axios.post(
        `${API_URL}/mensagens/enviar`,
        formData,
        {
          headers: {
            'Content-Type': 'multipart/form-data',
            'Authorization': `Bearer ${token}`
          }
        }
      );

      // Chame a função de upload após o envio do áudio
      await uploadFile(generateMessageId(), 'audio', audioData);
      console.log('Função de upload chamada após o envio do áudio');

      // Atualiza a mensagem como enviada
      setChats(prevChats => {
        return prevChats.map(chat => {
          if (chat.id === selectedUser.id) {
            return {
              ...chat,
              mensagens: chat.mensagens.map(msg => {
                if (msg.file === audioUrl) {
                  return { ...msg, uploaded: true, file: audioData };
                }
                return msg;
              })
            };
          }
          return chat;
        });
      });
      */

    } catch (error) {
      console.error('Erro ao enviar áudio:', error);
    }
  };

  const handleSendMessage = () => {
    if (!messageInput.trim() || !selectedUser) return;
  
    const messageId = generateMessageId();
    const newMessage = {
      id: messageId,
      message_id: messageId,
      sender_id: user.id,
      receiver_id: selectedUser.id,
      content: messageInput,
      message_type: 'text',
      file_url: null,
      file_name: null,
      file_size: null,
      is_delivered: false,
      reaction: null,
      is_read: false,
      created_at: new Date().toISOString()
    };
  
    try {
      socket.send(JSON.stringify({
        type: "message",
        to_user: selectedUser.id,
        message_id: messageId,
        content: messageInput,
        message_type: 'text',
        file_url: null,
        file_name: null,
        file_size: null,
      }));

      // Atualiza a lista de chats reordenando para colocar o chat no topo
      setChats((prevChats) => {
        const existingChatIndex = prevChats.findIndex(
          (chat) => chat.id === selectedUser.id
        );

        if (existingChatIndex !== -1) {
          const chat = prevChats[existingChatIndex];
          const updatedChat = {
            ...chat,
            mensagens: [...chat.mensagens, newMessage],
          };

          // Move o chat atualizado para o topo
          return [
            updatedChat,
            ...prevChats.filter((_, i) => i !== existingChatIndex),
          ];
        } else {
          // Se não existir, adiciona-o no início da lista
          return [
            {
              ...selectedUser,
              mensagens: [newMessage],
            },
            ...prevChats,
          ];
        }
      });

      // Atualiza também o chat selecionado para mostrar a nova mensagem
      setSelectedUser((prevUser) => ({
        ...prevUser,
        mensagens: [...(prevUser.mensagens || []), newMessage],
      }));

      setMessageInput('');

      // (Opcional) Scroll automático (se necessário, adapte para rolar para o final ou início)
      setTimeout(scrollToBottom, 100);
    } catch (error) {
      console.error('Error sending message:', error);
    }
  };

  const handleTyping = () => {
    if (!socket || socket.readyState !== WebSocket.OPEN || !selectedUser) return;

    socket.send(JSON.stringify({
      type: "typing",
      content: "typing...",
      to_user: selectedUser.id
    }));
  };

  const handleFileSelect = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    // Apenas log do arquivo para você implementar o envio depois
    console.log('Arquivo selecionado:', {
      name: file.name,
      type: file.type,
      size: file.size
    });

    // Preview do arquivo selecionado
    if (file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setMediaPreview(e.target.result);
        setMediaType('image');
        setSelectedFile(file);
      };
      reader.readAsDataURL(file);
    } else if (file.type.startsWith('audio/')) {
      setMediaPreview(URL.createObjectURL(file));
      setMediaType('audio');
      setSelectedFile(file);
    } else if (file.type.startsWith('application/') || file.type.startsWith('text/')) {
      setMediaPreview(file.name);
      setMediaType('document');
      setSelectedFile(file);
    }
  };

  const cancelMedia = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current = null;
    }
    if (mediaPreview && mediaType === 'audio') {
      URL.revokeObjectURL(mediaPreview);
    }
    setMediaPreview(null);
    setMediaType(null);
    setSelectedFile(null);
    if (mediaInputRef.current) {
      mediaInputRef.current.value = '';
    }
  };

  const startRecording = async () => {
    try {
      cancelMedia();
      
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      // Use explicit MIME type that matches server requirements
      const mediaRecorder = new MediaRecorder(stream, {
        mimeType: 'audio/wav'
      });
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      // Configurar visualização em tempo real
      if (!audioContextRef.current) {
        audioContextRef.current = new (window.AudioContext || window.webkitAudioContext)();
      }
      const analyser = audioContextRef.current.createAnalyser();
      analyserRef.current = analyser;
      const source = audioContextRef.current.createMediaStreamSource(stream);
      source.connect(analyser);
      analyser.fftSize = 256;
      
      drawWaveform();

      mediaRecorder.ondataavailable = (e) => {
        audioChunksRef.current.push(e.data);
      };

      mediaRecorder.start(100); // Start recording with 100ms time slices
      setIsRecording(true);
      setRecordingDuration(0);
    } catch (error) {
      // If WAV isn't supported, try WebM
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        const mediaRecorder = new MediaRecorder(stream, {
          mimeType: 'audio/webm'
        });
        mediaRecorderRef.current = mediaRecorder;
        // ...rest of the recording setup...
      } catch (fallbackError) {
        console.error('Erro ao acessar microfone:', fallbackError);
      }
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      const stream = mediaRecorderRef.current.stream;
      
      mediaRecorderRef.current.stop();
      setIsRecording(false);

      setTimeout(() => {
        const audioBlob = new Blob(audioChunksRef.current, { 
          type: mediaRecorderRef.current.mimeType
        });
        
        // Create a File object with explicit MIME type
        const fileName = `audio_${Date.now()}.${mediaRecorderRef.current.mimeType.includes('wav') ? 'wav' : 'webm'}`;
        const audioFile = new File([audioBlob], fileName, { 
          type: mediaRecorderRef.current.mimeType,
          lastModified: Date.now()
        });
        
        setSelectedFile(audioFile);
        
        if (mediaPreview) {
          URL.revokeObjectURL(mediaPreview);
        }
        const audioUrl = URL.createObjectURL(audioBlob);
        setMediaPreview(audioUrl);
        setMediaType('audio');
        setDuration(recordingDuration);
        
        stream.getTracks().forEach(track => track.stop());
        cancelAnimationFrame(animationFrameRef.current);
      }, 200);
    }
  };

  const drawWaveform = useCallback(() => {
    if (!analyserRef.current || !canvasRef.current) return;

    const canvas = canvasRef.current;
    const canvasCtx = canvas.getContext('2d');
    const analyser = analyserRef.current;
    const bufferLength = analyser.frequencyBinCount;
    const dataArray = new Uint8Array(bufferLength);

    const draw = () => {
      animationFrameRef.current = requestAnimationFrame(draw);
      analyser.getByteTimeDomainData(dataArray);

      canvasCtx.fillStyle = 'rgb(255, 255, 255)';
      canvasCtx.fillRect(0, 0, canvas.width, canvas.height);
      canvasCtx.lineWidth = 2;
      canvasCtx.strokeStyle = 'rgb(99, 102, 241)';
      canvasCtx.beginPath();

      const sliceWidth = canvas.width / bufferLength;
      let x = 0;

      for (let i = 0; i < bufferLength; i++) {
        const v = dataArray[i] / 128.0;
        const y = v * canvas.height / 2;

        if (i === 0) {
          canvasCtx.moveTo(x, y);
        } else {
          canvasCtx.lineTo(x, y);
        }

        x += sliceWidth;
      }

      canvasCtx.lineTo(canvas.width, canvas.height / 2);
      canvasCtx.stroke();
    };

    draw();
  }, [isRecording]);

  const toggleAudioPlayback = async (messageId, audioUrl) => {
    if (!audioUrl) return;

    setAudioStates(prevStates => {
      const currentState = prevStates[messageId] || {};
      const currentAudio = currentState.audio;

      // Stop any other playing audio
      Object.values(prevStates).forEach(state => {
        if (state.audio && state.audio !== currentAudio) {
          state.audio.pause();
        }
      });

      // If we already have an audio instance
      if (currentAudio) {
        if (currentState.isPlaying) {
          currentAudio.pause();
          return {
            ...prevStates,
            [messageId]: { ...currentState, isPlaying: false }
          };
        } else {
          currentAudio.play();
          return {
            ...prevStates,
            [messageId]: { ...currentState, isPlaying: true }
          };
        }
      }

      // Create new audio instance
      const audio = new Audio(audioUrl);
      
      audio.addEventListener('timeupdate', () => {
        setAudioStates(prev => ({
          ...prev,
          [messageId]: {
            ...prev[messageId],
            currentTime: audio.currentTime
          }
        }));
      });

      audio.addEventListener('loadedmetadata', () => {
        setAudioStates(prev => ({
          ...prev,
          [messageId]: {
            ...prev[messageId],
            duration: audio.duration
          }
        }));
      });

      audio.addEventListener('ended', () => {
        setAudioStates(prev => ({
          ...prev,
          [messageId]: {
            ...prev[messageId],
            isPlaying: false,
            currentTime: 0
          }
        }));
      });

      // Handle errors
      audio.addEventListener('error', (e) => {
        console.error('Erro ao carregar áudio:', e);
        setAudioStates(prev => ({
          ...prev,
          [messageId]: {
            ...prev[messageId],
            error: true
          }
        }));
      });

      audio.play().catch(error => {
        console.error('Erro ao tocar áudio:', error);
      });

      return {
        ...prevStates,
        [messageId]: {
          audio,
          isPlaying: true,
          currentTime: 0,
          duration: 0
        }
      };
    });
  };

  // Cleanup audio resources on unmount
  useEffect(() => {
    return () => {
      Object.values(audioStates).forEach(state => {
        if (state.audio) {
          state.audio.pause();
          state.audio.src = '';
        }
      });
    };
  }, []);

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  useEffect(() => {
    let interval;
    if (isRecording) {
      interval = setInterval(() => {
        setRecordingDuration(prev => prev + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isRecording]);

  // Limpa recursos quando o componente é desmontado
  useEffect(() => {
    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
      if (mediaPreview && mediaType === 'audio') {
        URL.revokeObjectURL(mediaPreview);
      }
      cancelAnimationFrame(animationFrameRef.current);
    };
  }, []);

  const handleBackClick = () => {
    if (view === 'info') {
      setView('messages');
      setShowUser(false);
    } else if (view === 'messages') {
      setView('chats');
      setSelectedUser(null);
    }
  };

  const toggleFriendsList = () => {
    setShowOnlineUsers(!showOnlineUsers);
  };

  const filteredFriends = friends.filter(friend => 
    friend.nome.toLowerCase().includes(searchQuery.toLowerCase()) ||
    friend.username.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getLastMessage = (chat) => {
    if (!chat.mensagens || chat.mensagens.length === 0) return '';
    const lastMsg = chat.mensagens[chat.mensagens.length - 1];
    return lastMsg.content;
  };

  const ChatSkeleton = () => (
    <>
      {[1, 2, 3, 4, 5].map((item) => (
        <div key={item} className="flex gap-4 items-center hover:bg-gray-50 p-2 px-8 animate-pulse">
          <div className="w-[56px] h-[56px] rounded-full bg-gray-200" />
          <div className="flex-1">
            <div className="h-4 bg-gray-200 rounded w-24 mb-2" />
            <div className="h-3 bg-gray-200 rounded w-32" />
          </div>
        </div>
      ))}
    </>
  );

  const FriendsSkeleton = () => (
    <>
      {[1, 2, 3, 4, 5].map((item) => (
        <div key={item} className="flex gap-4 items-center p-2 px-8 animate-pulse">
          <div className="w-[56px] h-[56px] rounded-full bg-gray-200" />
          <div className="flex-1">
            <div className="h-4 bg-gray-200 rounded w-24 mb-2" />
            <div className="h-3 bg-gray-200 rounded w-32" />
          </div>
        </div>
      ))}
    </>
  );

  // Função para atualizar a mensagem após o upload
  const updateMessageAfterUpload = (messageId, uploadResponse) => {
    setChats(prevChats => {
      return prevChats.map(chat => {
        if (chat.mensagens) {
          const updatedMensagens = chat.mensagens.map(msg => {
            if (msg.id === messageId || msg.message_id === messageId) {
              return {
                ...msg,
                file_url: uploadResponse.file_url,
                file_name: uploadResponse.file_name || msg.file_name,
                file_size: uploadResponse.file_size || msg.file_size,
                status: 'sent'
              };
            }
            return msg;
          });
          return { ...chat, mensagens: updatedMensagens };
        }
        return chat;
      });
    });

    setSelectedUser(prevUser => {
      if (prevUser.mensagens) {
        const updatedMensagens = prevUser.mensagens.map(msg => {
          if (msg.id === messageId || msg.message_id === messageId) {
            return {
              ...msg,
              file_url: uploadResponse.file_url,
              file_name: uploadResponse.file_name || msg.file_name,
              file_size: uploadResponse.file_size || msg.file_size,
              status: 'sent'
            };
          }
          return msg;
        });
        return { ...prevUser, mensagens: updatedMensagens };
      }
      return prevUser;
    });
  };

  // Função para marcar a mensagem com erro
  const updateMessageWithError = (messageId) => {
    setChats(prevChats => {
      return prevChats.map(chat => {
        if (chat.mensagens) {
          const updatedMensagens = chat.mensagens.map(msg => {
            if (msg.id === messageId || msg.message_id === messageId) {
              return { ...msg, status: 'error' };
            }
            return msg;
          });
          return { ...chat, mensagens: updatedMensagens };
        }
        return chat;
      });
    });

    setSelectedUser(prevUser => {
      if (prevUser.mensagens) {
        const updatedMensagens = prevUser.mensagens.map(msg => {
          if (msg.id === messageId || msg.message_id === messageId) {
            return { ...msg, status: 'error' };
          }
          return msg;
        });
        return { ...prevUser, mensagens: updatedMensagens };
      }
      return prevUser;
    });
  };

  // Função para atualizar mensagens por ID em todos os locais (chats e selectedUser)
  const updateMessageById = (messageId, updateFn) => {
    // Atualiza na lista de chats
    setChats(prevChats => {
      return prevChats.map(chat => {
        if (chat.mensagens) {
          const updatedMensagens = chat.mensagens.map(msg => {
            if (msg.message_id === messageId || msg.id === messageId) {
              // Aplica a função de atualização
              return updateFn(msg);
            }
            return msg;
          });
          return { ...chat, mensagens: updatedMensagens };
        }
        return chat;
      });
    });

    // Atualiza no usuário selecionado, se existir
    if (selectedUser) {
      setSelectedUser(prevUser => {
        if (prevUser.mensagens) {
          const updatedMensagens = prevUser.mensagens.map(msg => {
            if (msg.message_id === messageId || msg.id === messageId) {
              // Aplica a função de atualização
              return updateFn(msg);
            }
            return msg;
          });
          return { ...prevUser, mensagens: updatedMensagens };
        }
        return prevUser;
      });
    }
  };

  return (
    <div className='flex h-screen overflow-hidden'>
      {/* Chat list sidebar */}
      <div className={`w-full md:w-[350px] flex flex-col border-r border-gray-200 ${
        view !== 'chats' ? 'hidden md:flex' : ''
      }`}>
        {/* User profile header */}
        <div className="flex items-center gap-4 flex-col px-8 pt-6">
          <div className='flex justify-between items-center w-full'>
            <h1 className="font-bold text-lg">{user.username}</h1>
            <Edit size={20} className="cursor-pointer"/>
          </div>
          <div className="flex gap-4 w-full h-[150px] flex-col pt-6">
            <img 
              src={user.perfil} 
              alt="profile" 
              className="w-[60px] h-[60px] rounded-full border"
              onError={(e) => e.target.src = `${base_url}/avatar.png`}
            />
            <span className='text-gray-500'>{user?.name}</span>
          </div>
        </div>

        {/* Chat list */}
        <div className="flex-1 overflow-hidden flex flex-col min-h-0">
          <div className="flex justify-between w-full px-8 py-2">
            <h1 className='font-bold text-gray-900'>Mensagens</h1>
            <h1 className='font-bold text-gray-500'>Comentarios</h1>
          </div>
          
          <div className="flex-1 overflow-y-auto">
            {gettingChats ? (
              <ChatSkeleton />
            ) : (
              chats.map(chat => (
                <div 
                  key={chat.id} 
                  className={`flex gap-4 items-center hover:bg-gray-50 p-2 px-8 cursor-pointer ${
                    selectedUser?.id === chat.id ? 'bg-gray-100' : ''
                  }`}
                  onClick={() => handleUserSelect(chat)}
                >
                  <img 
                    src={chat.foto} 
                    alt={chat.nome}
                    className='w-[56px] h-[56px] rounded-full border'
                    onError={(e) => e.target.src = `${base_url}/avatar.png`}
                  />
                  <div className="flex flex-col">
                    <label className='font-sm text-nowrap'>{chat.nome}</label>
                    <label className='text-xs text-gray-500'>{getLastMessage(chat)}</label>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Main chat area */}
      <div className={`flex-1 flex flex-col h-screen overflow-hidden ${
        view === 'chats' ? 'hidden md:flex' : ''
      }`}>
        {!selectedUser ? (
          <div className="flex-1 flex items-center justify-center">
            <div className="flex flex-col items-center gap-3">
              <div className="w-[100px] h-[100px] rounded-full border-2 border-gray-950 flex justify-center items-center">
                <MessageCirclePlus size={50}/>
              </div>
              <h1 className='text-xl'>As tuas mensagens</h1>
              <span className='text-gray-400'>Envia fotos e mensagens privadas para um amigo ou grupo.</span>
              <button 
                className='py-2 px-4 rounded-md bg-indigo-500 text-white'
                onClick={toggleFriendsList}
              >
                Enviar mensagem
              </button>
            </div>
          </div>
        ) : (
          <div className={`flex flex-1 min-h-0 ${view === 'info' ? 'hidden md:flex' : ''}`}>
            {/* Chat messages */}
            <div className="flex-1 flex flex-col min-h-0">
              <div className="flex items-center justify-between p-4 border-b">
                <div className="flex items-center gap-4">
                  <ArrowLeft 
                    className="cursor-pointer md:hidden" 
                    onClick={handleBackClick}
                  />
                  <img 
                    src={selectedUser.foto}
                    alt={selectedUser.nome}
                    className="w-8 h-8 md:w-10 md:h-10 rounded-full"
                    onError={(e) => e.target.src = `${base_url}/avatar.png`}
                  />
                  <Link to={`/${selectedUser.username}`} className='font-semibold hover:underline hover:text-indigo-500'>
                    {selectedUser.nome}
                  </Link>
                  {userTyping === selectedUser.username && (
                    <span className="text-sm text-green-500">digitando...</span>
                  )}
                </div>
                <Info 
                  className="cursor-pointer" 
                  onClick={() => setShowUser(true)}
                />
              </div>

              {/* Messages container */}
              <div className="flex-1 overflow-y-auto p-4">
                {selectedUser.mensagens && selectedUser.mensagens.length > 0 ? (
                  selectedUser.mensagens.map((message) => (
                    <MessageItem key={message.id} message={message} />
                  ))
                ) : (
                  <div className="flex flex-col items-center justify-center h-full text-gray-500">
                    <MessageCirclePlus size={40} className="mb-2" />
                    <p>Comece uma conversa com {selectedUser.nome}</p>
                  </div>
                )}
                <div ref={messagesEndRef} />
              </div>

              {/* Input area - fixed at bottom */}
              <div className="p-4 border-t bg-white">
                {/* Preview dos arquivos */}
                {mediaPreview && !isRecording && (
                  <div className="mb-3 bg-gray-100 p-3 rounded-lg relative">
                    {mediaType === 'image' ? (
                      <div className="relative">
                        <img 
                          src={mediaPreview} 
                          alt="Preview" 
                          className="max-h-[200px] rounded-lg object-contain w-full"
                        />
                        <div className="absolute top-2 right-2">
                          <button 
                            onClick={() => {
                              setMediaPreview('');
                              setMediaType('');
                              setSelectedFile(null);
                            }}
                            className="p-1 bg-gray-800 bg-opacity-70 text-white rounded-full"
                          >
                            <X size={16} />
                          </button>
                        </div>
                      </div>
                    ) : mediaType === 'video' ? (
                      <div className="relative">
                        <video 
                          src={mediaPreview} 
                          controls 
                          className="max-h-[200px] rounded-lg w-full"
                        />
                        <div className="absolute top-2 right-2">
                          <button 
                            onClick={() => {
                              setMediaPreview('');
                              setMediaType('');
                              setSelectedFile(null);
                            }}
                            className="p-1 bg-gray-800 bg-opacity-70 text-white rounded-full"
                          >
                            <X size={16} />
                          </button>
                        </div>
                      </div>
                    ) : (
                      <div className="flex items-center gap-3">
                        <div className="bg-white p-2 rounded-lg">
                          <File size={32} className="text-indigo-500" />
                        </div>
                        <div className="flex-1">
                          <div className="text-sm font-medium truncate">
                            {selectedFile?.name || 'Arquivo'}
                          </div>
                          <div className="text-xs text-gray-500">
                            {selectedFile?.size ? `${(selectedFile.size / (1024 * 1024)).toFixed(2)} MB` : ''}
                          </div>
                        </div>
                        <button 
                          onClick={() => {
                            setMediaPreview('');
                            setMediaType('');
                            setSelectedFile(null);
                          }}
                          className="p-1 text-gray-500 hover:text-gray-700"
                        >
                          <X size={16} />
                        </button>
                      </div>
                    )}
                  </div>
                )}

                {/* Recording UI */}
                {isRecording && (
                  <div className="flex items-center gap-4 p-3 bg-red-50 rounded-lg">
                    <div className="flex items-center gap-3 flex-1">
                      <div className="relative">
                        <div className="w-12 h-12 rounded-full bg-red-100 flex items-center justify-center">
                          <Mic size={24} className="text-red-500" />
                          <div className="absolute inset-0 rounded-full border-2 border-red-500 animate-ping opacity-75"></div>
                        </div>
                      </div>
                      
                      <div className="flex-1">
                        <canvas 
                          ref={canvasRef} 
                          className="w-full h-8 bg-red-100 rounded-lg"
                        />
                        <div className="flex justify-between items-center mt-1">
                          <span className="text-sm text-red-600">
                            {formatTime(recordingDuration)}
                          </span>
                          <span className="text-sm text-red-600 animate-pulse">
                            Gravando...
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button 
                        onClick={cancelMedia}
                        className="p-2.5 bg-white text-red-500 rounded-full hover:bg-red-50 transition-colors"
                      >
                        <X size={20} />
                      </button>
                      <button 
                        onClick={stopRecording}
                        className="p-2.5 bg-white text-indigo-600 rounded-full hover:bg-indigo-50 transition-colors"
                      >
                        <Send size={20} />
                      </button>
                    </div>
                  </div>
                )}

                {/* Regular input area - only show when not recording */}
                {!isRecording && (
                  <div className="flex p-2 border rounded-full gap-4 px-4 items-center">
                    <div className="flex items-center gap-2">
                      <Smile className="cursor-pointer"/>
                      <input
                        type="file"
                        ref={mediaInputRef}
                        onChange={handleFileSelect}
                        className="hidden"
                        accept="image/*,audio/*,.pdf,.doc,.docx,.txt"
                      />
                      <button 
                        onClick={() => mediaInputRef.current.click()}
                        className="p-1 hover:bg-gray-100 rounded-full"
                      >
                        <Image size={20} className="text-gray-500"/>
                      </button>
                      <button 
                        onClick={() => mediaInputRef.current.click()}
                        className="p-1 hover:bg-gray-100 rounded-full"
                      >
                        <File size={20} className="text-gray-500"/>
                      </button>
                      <button 
                        onClick={startRecording}
                        className="p-1 hover:bg-gray-100 rounded-full"
                      >
                        <Mic size={20} className="text-gray-500" />
                      </button>
                    </div>
                    
                    <input
                      type="text"
                      value={messageInput}
                      onChange={(e) => {
                        setMessageInput(e.target.value);
                        handleTyping();
                      }}
                      onKeyPress={(e) => {
                        if (e.key === 'Enter') {
                          if (mediaPreview) {
                            handleSendMessageWithFile();
                          } else {
                            handleSendMessage();
                          }
                        }
                      }}
                      placeholder="Digite sua mensagem..."
                      className="flex-1 outline-none bg-transparent"
                    />
                    
                    {mediaPreview ? (
                      <button 
                        className="px-4 py-1.5 bg-indigo-500 text-white rounded-full text-sm font-medium hover:bg-indigo-600"
                        onClick={handleSendMessageWithFile}
                      >
                        Enviar
                      </button>
                    ) : (
                      messageInput.trim() && (
                        <button 
                          className="px-4 py-1.5 bg-indigo-500 text-white rounded-full text-sm font-medium hover:bg-indigo-600"
                          onClick={handleSendMessage}
                        >
                          Enviar
                        </button>
                      )
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* User info sidebar - reduced photo size for mobile */}
      {showUser && (
        <div className={`w-full md:w-[380px] border-l border-gray-200 flex flex-col min-h-0 ${
          view !== 'info' ? 'hidden md:flex' : ''
        }`}>
          <div className="flex items-center justify-between p-4 border-b">
            <ArrowLeft className="cursor-pointer" onClick={handleBackClick}/>
            <Link to={`/${selectedUser.username}`} className='hover:underline hover:text-indigo-500'>
              {selectedUser.nome}
            </Link>
          </div>

          <div className="flex-1 overflow-y-auto">
            <div className="flex flex-col items-center gap-4">
              <div className="flex p-4 md:p-8 w-full flex-col items-center gap-4">
                <img 
                  src={selectedUser.foto}
                  alt={selectedUser.nome}
                  className="w-[120px] h-[120px] md:w-[200px] md:h-[200px] rounded-full"
                  onError={(e) => e.target.src = `${base_url}/avatar.png`}
                />
                <Link to={`/${selectedUser.username}`} className='font-bold text-xl md:text-2xl hover:underline hover:text-indigo-500'>
                  {selectedUser.nome}
                </Link>
              </div>

              <div className="flex w-full gap-4 justify-center">
                <div className="flex gap-2 hover:text-indigo-600 cursor-pointer">
                  <Grid size={20}/>
                  <span>Boldas</span>
                  <span className='font-bold text-indigo-500'>65</span>
                </div>
                <div className="flex gap-2 hover:text-indigo-600 cursor-pointer">
                  <Newspaper size={20}/>
                  <span>Publicacoes</span>
                  <span className='font-bold text-indigo-500'>190</span>
                </div>
              </div>

              <div className="w-full border-t">
                <div className="flex gap-3 hover:bg-gray-100 p-4 px-8 cursor-pointer">
                  <Heart size={20}/>
                  <span>Adicionar aos favorios</span>
                </div>
                <div className="flex gap-3 hover:bg-gray-100 p-4 px-8 cursor-pointer text-red-500">
                  <Ban size={20}/>
                  <span>Bloaquar o/a {selectedUser.nome}</span>
                </div>
                <div className="flex gap-3 hover:bg-gray-100 p-4 px-8 cursor-pointer text-red-500">
                  <ThumbsDown size={20}/>
                  <span>Denuciar o/a {selectedUser.nome}</span>
                </div>
                <div className="flex gap-3 hover:bg-gray-100 p-4 px-8 cursor-pointer text-red-500">
                  <Trash size={20}/>
                  <span>Apagar mensagens</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Friends list modal */}
      {showOnlineUsers && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg w-full max-w-md max-h-[80vh] flex flex-col">
            <div className="flex items-center justify-between p-4 border-b">
              <h2 className="text-xl font-bold">Iniciar nova conversa</h2>
              <X 
                className="cursor-pointer" 
                onClick={() => setShowOnlineUsers(false)}
              />
            </div>
            
            <div className="p-4 border-b">
              <div className="relative">
                <input
                  type="text"
                  placeholder="Pesquisar amigos..."
                  className="w-full p-2 pl-10 border rounded-lg"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
                <Search className="absolute left-3 top-2.5 text-gray-400" size={18} />
              </div>
            </div>
            
            <div className="flex-1 overflow-y-auto">
              {loadingFriends ? (
                <FriendsSkeleton />
              ) : filteredFriends.length > 0 ? (
                filteredFriends.map(friend => (
                  <div 
                    key={friend.id} 
                    className="flex items-center gap-4 p-4 hover:bg-gray-50 cursor-pointer"
                    onClick={() => {
                      handleFriendSelect(friend);
                      setShowOnlineUsers(false);
                    }}
                  >
                    <img 
                      src={friend.foto_perfil}
                      alt={friend.nome}
                      className="w-12 h-12 rounded-full"
                      onError={(e) => e.target.src = `${base_url}/avatar.png`}
                    />
                    <div>
                      <p className="font-semibold">{friend.nome}</p>
                      <p className="text-sm text-gray-500">@{friend.username}</p>
                    </div>
                  </div>
                ))
              ) : (
                <div className="p-4 text-center text-gray-500">
                  {searchQuery ? 'Nenhum amigo encontrado' : 'Nenhum amigo disponível'}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Floating Action Button for new chat */}
      {view === 'chats' && !showOnlineUsers && (
        <button 
          className="fixed bottom-6 right-6 w-14 h-14 rounded-full bg-indigo-600 text-white flex items-center justify-center shadow-lg hover:bg-indigo-700 transition-colors z-10"
          onClick={toggleFriendsList}
        >
          <Plus size={24} />
        </button>
      )}
    </div>
  );
}