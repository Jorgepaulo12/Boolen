import React, { useState, useEffect, useRef } from 'react'
import { useAuth } from '../../../context/AuthContext'
import { Loader, AlertCircle, Check, CheckCheck, Play, Pause, X } from 'lucide-react'
import { getAudioDuration, formatAudioDuration } from '../../../utils/audioUtils'
import './MessageItem.css'

export default function MessageItem({ message }) {
    const {user} = useAuth()
    const [isPlaying, setIsPlaying] = useState(false);
    const [duration, setDuration] = useState(0);
    const [currentTime, setCurrentTime] = useState(0);
    const [showImageViewer, setShowImageViewer] = useState(false);
    const audioRef = useRef(null);
    
    // Determinar se a mensagem é do usuário atual ou de outro usuário
    const isMyMessage = message.sender_id === user.id;
    
    // Assegura compatibilidade com mensagens antigas que podem usar type em vez de message_type
    const messageType = message.message_type || message.type || 'text';
    const fileUrl = message.file_url || message.file;
    const isUploading = message.status === 'uploading';
    const hasError = message.status === 'error';
    
    // Carregar duração do áudio quando o componente montar, se for um áudio
    useEffect(() => {
        if (messageType === 'audio' && fileUrl && !duration) {
            getAudioDuration(fileUrl).then(audioDuration => {
                setDuration(audioDuration);
            });
        }
    }, [messageType, fileUrl, duration]);
    
    // Formatar o tempo para exibição (mm:ss)
    const formatTime = (seconds) => {
        if (!seconds || isNaN(seconds) || !isFinite(seconds)) {
            return '0:00';
        }
        const mins = Math.floor(seconds / 60);
        const secs = Math.floor(seconds % 60);
        return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
    };
    
    // Formatar hora (hh:mm)
    const getHours = (timestamp) => {
        const date = new Date(timestamp);
        return date.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
    };
    
    // Lidar com a reprodução de áudio
    const toggleAudio = () => {
        if (!audioRef.current) return;
        
        if (isPlaying) {
            audioRef.current.pause();
        } else {
            audioRef.current.play().catch(err => {
                console.error("Erro ao reproduzir áudio:", err);
                setIsPlaying(false);
            });
        }
        setIsPlaying(!isPlaying);
    };
    
    // Abrir visualizador de imagem
    const openImageViewer = () => {
        setShowImageViewer(true);
    };
    
    // Fechar visualizador de imagem
    const closeImageViewer = () => {
        setShowImageViewer(false);
    };
    
    // Prevenir propagação de eventos ao clicar no diálogo
    const handleDialogClick = (e) => {
        e.stopPropagation();
    };
    
    // Atualizar o tempo atual durante a reprodução
    useEffect(() => {
        if (audioRef.current && messageType === 'audio') {
            const audio = audioRef.current;
            
            // Pré-carregar o áudio para garantir que metadata esteja disponível
            audio.load();
            
            const handleTimeUpdate = () => {
                setCurrentTime(audio.currentTime);
            };
            
            const handleLoadedMetadata = () => {
                if (audio.duration && isFinite(audio.duration)) {
                    setDuration(audio.duration);
                } else {
                    setDuration(0);
                }
            };
            
            const handleEnded = () => {
                setIsPlaying(false);
                setCurrentTime(0);
            };
            
            // Adicionar event listeners
            audio.addEventListener('timeupdate', handleTimeUpdate);
            audio.addEventListener('loadedmetadata', handleLoadedMetadata);
            audio.addEventListener('ended', handleEnded);
            
            // Tentar definir a duração imediatamente, caso os metadados já estejam carregados
            if (audio.readyState >= 1 && isFinite(audio.duration)) {
                setDuration(audio.duration);
            }
            
            // Cleanup
            return () => {
                audio.removeEventListener('timeupdate', handleTimeUpdate);
                audio.removeEventListener('loadedmetadata', handleLoadedMetadata);
                audio.removeEventListener('ended', handleEnded);
            };
        }
    }, [messageType]);
    
    // Renderiza o status da mensagem
    const renderMessageStatus = () => {
        if (isUploading) {
            return <Loader size={16} className="animate-spin text-gray-400" />;
        }
        
        if (hasError) {
            return <AlertCircle size={16} className="text-red-500" />;
        }
        
        if (message.is_read) {
            return <CheckCheck size={16} className="text-blue-400" />;
        }
        
        if (message.is_delivered) {
            return <CheckCheck size={16} className="text-gray-400" />;
        }
        
        return <Check size={16} className="text-gray-400" />;
    };
   
    // Player de áudio personalizado
    const renderCustomAudioPlayer = () => {
        // Calcular a porcentagem baseada na duração real, se disponível
        const progressPercentage = duration > 0 
            ? Math.min((currentTime / duration) * 100, 100) 
            : isPlaying ? Math.min((currentTime / 60) * 100, 100) : 0;
        
        return (
            <div className={`flex items-center gap-2 w-[300px] ${isPlaying ? 'audio-playing' : ''}`}>
                {/* Botão de play/pause */}
                <button 
                    onClick={toggleAudio}
                    className={`w-8 h-8 rounded-full flex items-center justify-center ${isPlaying ? 'bg-blue-100 text-blue-600' : 'bg-skyvenda-100 text-skyvenda-600'}`}
                >
                    {isPlaying ? <Pause size={16} /> : <Play size={16} />}
                </button>
                
                {/* Barra de progresso */}
                <div className="flex-1">
                    <div className="w-full h-1.5 bg-gray-200 rounded-full overflow-hidden">
                        <div 
                            className={`h-full rounded-full progress-bar ${isPlaying ? 'bg-skyvenda-500' : 'bg-gray-300'}`}
                            style={{ width: `${progressPercentage}%` }}
                        />
                    </div>
                    <div className="flex justify-between text-xs text-gray-500 mt-1">
                        <span>{formatTime(currentTime)}</span>
                        {duration > 0 ? (
                            <span>{formatTime(duration)}</span>
                        ) : (
                            <span className={isPlaying ? 'text-skyvenda-500' : ''}>
                                {isPlaying ? "Reproduzindo..." : "Toque para ouvir"}
                            </span>
                        )}
                    </div>
                </div>
                
                {/* Audio element (hidden) */}
                <audio 
                    ref={audioRef} 
                    src={fileUrl} 
                    className="hidden" 
                    preload="metadata"
                    onError={() => {
                        console.error("Erro ao carregar áudio:", fileUrl);
                        setDuration(0);
                    }}
                />
            </div>
        );
    };
   
    // Renderiza o conteúdo do arquivo de acordo com o tipo
    const renderFileContent = () => {
        if (isUploading) {
            switch(messageType) {
                case 'audio':
                    return (
                        <div className="flex items-center p-2 bg-gray-100 rounded-lg animate-pulse gap-2 w-[300px]">
                            <div className="w-8 h-8 rounded-full bg-gray-300 flex items-center justify-center">
                                <Loader size={16} className="animate-spin" />
                            </div>
                            <div className="flex-1">
                                <div className="bg-gray-300 h-1.5 rounded-full w-full"></div>
                            </div>
                            <span className="text-xs text-gray-500">Enviando...</span>
                        </div>
                    );
                case 'image':
                    return (
                        <div className="relative w-full">
                            <img 
                                src={fileUrl} 
                                alt="Enviando imagem" 
                                className="w-full rounded-lg max-h-[200px] object-contain opacity-75" 
                            />
                            <div className="absolute inset-0 flex items-center justify-center">
                                <div className="bg-black bg-opacity-50 rounded-full p-2">
                                    <Loader size={20} className="animate-spin text-white" />
                                </div>
                            </div>
                        </div>
                    );
                default:
                    return (
                        <div className="flex items-center gap-2 text-gray-500">
                            <Loader size={16} className="animate-spin" />
                            <span>Enviando arquivo...</span>
                        </div>
                    );
            }
        }
        
        if (hasError) {
            return (
                <div className="flex items-center gap-2 text-red-500">
                    <AlertCircle size={16} />
                    <span>Erro ao enviar</span>
                </div>
            );
        }
        
        switch(messageType) {
            case 'audio':
                return renderCustomAudioPlayer();
            case 'image':
                return (
                    <div 
                        className="w-full cursor-pointer"
                        onClick={openImageViewer}
                    >
                        <img 
                            src={fileUrl} 
                            alt="Imagem" 
                            className="w-full rounded-lg max-h-[200px] object-contain" 
                        />
                    </div>
                );
            case 'video':
                return (
                    <div className="w-[300px]">
                        <video 
                            src={fileUrl} 
                            controls 
                            className="w-full rounded-lg max-h-[200px]"
                        />
                    </div>
                );
            case 'pdf':
                return (
                    <a href={fileUrl} target="_blank" rel="noopener noreferrer" 
                       className="flex items-center gap-2 p-2 bg-gray-100 rounded-lg hover:bg-gray-200 w-[300px]">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                            <polyline points="14 2 14 8 20 8"></polyline>
                            <line x1="16" y1="13" x2="8" y2="13"></line>
                            <line x1="16" y1="17" x2="8" y2="17"></line>
                            <polyline points="10 9 9 9 8 9"></polyline>
                        </svg>
                        <span className="truncate">{message.file_name || 'Documento PDF'}</span>
                    </a>
                );
            default:
                return (
                    <a href={fileUrl} target="_blank" rel="noopener noreferrer" 
                       className="flex items-center gap-2 p-2 bg-gray-100 rounded-lg hover:bg-gray-200 w-[300px]">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"></path>
                            <polyline points="13 2 13 9 20 9"></polyline>
                        </svg>
                        <span className="truncate">{message.file_name || 'Arquivo anexado'}</span>
                    </a>
                );
        }
    };
   
    return (
        <>
            <div className={`flex ${isMyMessage ? 'justify-end' : 'justify-start'} mb-4`}>
                {isMyMessage ? (
                    <div className={`p-3 rounded-lg bg-skyvenda-100 ${messageType === 'text' ? 'max-w-[70%] flex gap-2 items-center' : messageType === 'image' ? 'max-w-[300px]' : ''}`}>
                        <div className="flex flex-1 text-gray-500">
                            {messageType === 'text' ? (
                                <div className="break-words">{message.content}</div>
                            ) : (
                                <div>
                                    {renderFileContent()}
                                    {message.content && message.content.trim() && (
                                        <div className="mt-2 break-words text-gray-500">{message.content}</div>
                                    )}
                                </div>
                            )}
                        </div>
                        
                        {messageType === 'text' && (
                            <div className="flex gap-1 text-xs text-gray-500">
                                <span>{getHours(message.created_at)}</span>
                                {renderMessageStatus()}
                            </div>
                        )}
                        
                        {messageType !== 'text' && (
                            <div className="flex gap-1 text-xs text-gray-500 mt-2 justify-end">
                                <span>{getHours(message.created_at)}</span>
                                {renderMessageStatus()}
                            </div>
                        )}
                    </div>
                ) : (
                    <div className={`p-3 rounded-lg bg-gray-100 ${messageType === 'text' ? 'max-w-[70%]' : messageType === 'image' ? 'max-w-[300px]' : ''}`}>
                        {messageType === 'text' ? (
                            <div>
                                <div className="break-words">{message.content}</div>
                                <div className="text-xs text-gray-500 mt-1">
                                    {getHours(message.created_at)}
                                </div>
                            </div>
                        ) : (
                            <div>
                                {renderFileContent()}
                                {message.content && message.content.trim() && (
                                    <div className="mt-2 break-words">{message.content}</div>
                                )}
                                <div className="text-xs text-gray-500 mt-1">
                                    {getHours(message.created_at)}
                                </div>
                            </div>
                        )}
                    </div>
                )}
            </div>

            {/* Modal de visualização de imagem */}
            {showImageViewer && messageType === 'image' && (
                <div 
                    className="fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center z-50"
                    onClick={closeImageViewer}
                >
                    <div 
                        className="relative max-w-[90%] max-h-[90%]" 
                        onClick={handleDialogClick}
                    >
                        <button 
                            className="absolute top-2 right-2 bg-black bg-opacity-50 rounded-full p-1 text-white"
                            onClick={closeImageViewer}
                        >
                            <X size={24} />
                        </button>
                        <img 
                            src={fileUrl} 
                            alt="Imagem em tamanho completo" 
                            className="max-w-full max-h-[90vh] object-contain" 
                        />
                    </div>
                </div>
            )}
        </>
    );
}
