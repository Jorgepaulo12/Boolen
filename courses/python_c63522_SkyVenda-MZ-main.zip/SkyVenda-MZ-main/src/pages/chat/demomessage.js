[
   
    {
        "id": 414,
        "message_id": null,
        "sender_id": 1,
        "receiver_id": 3,
        "content": "ola",
        "message_type": "text",
        "file_url": null,
        "file_name": null,
        "file_size": null,
        "is_delivered": false,
        "reaction": null,
        "is_read": false,
        "created_at": "2025-03-09T02:30:24.040691+00:00"
    },
    {
        "id": 420,
        "message_id": "m82qhgwblmbc0",
        "sender_id": 1,
        "receiver_id": 3,
        "content": "",
        "message_type": "audio",
        "file_url": "https://storage.googleapis.com/meu-novo-bucket-123/chat/1/3/7d824b9a-158a-4679-b6d0-aa5b527c2037.wav?X-Goog-Algorithm=GOOG4-RSA-SHA256&X-Goog-Credential=skyvenda%40meuvm-448009.iam.gserviceaccount.com%2F20250310%2Fauto%2Fstorage%2Fgoog4_request&X-Goog-Date=20250310T072133Z&X-Goog-Expires=86399&X-Goog-SignedHeaders=host&X-Goog-Signature=2749519097e6831a06c2d0a482e7bd101fa60526fb2decb0fcb6690ce3ce30ea89051c4145d575f546e4e8191a69ddd41abedcb867fd9256bcfc4972c702c79e8c2f6a7c66e6065cc4c534c2447d3ce4f2234e2dadbe147f2cfd0cbc43c0fccad7efb73675000edc9d20d32b477d6c7c727f0c69c326da83a4ca39240d7a7f845702610fc735ad46c9874e0f379f6547cde2858268e28708a04cf8a204fe8e6ff8ee69038b30c1d5b86d4c281b3c66a27fb47bc617cabeec0f78482bd80fd3fad08c3f97fa728b770dd0338180305f5fa1f7cea1f638fe96f1dd7b6f755e6316e2cff297668d506880860f80be1883f8704672149a6f98794e7c3d4960e2b587",
        "file_name": "",
        "file_size": 0,
        "is_delivered": false,
        "reaction": null,
        "is_read": false,
        "created_at": "2025-03-10T07:20:02.993661+00:00"
    }
]