import React from 'react'
import { SellersGrid } from './sellergrid'

export default function Sellers() {
  return (
    <div className='p-1'><SellersGrid/></div>
  )
}
