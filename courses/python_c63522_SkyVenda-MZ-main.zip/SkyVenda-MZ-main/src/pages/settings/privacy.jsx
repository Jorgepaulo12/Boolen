import React from 'react'

export default function Privacy() {
  return (
    <div>Privacy</div>
  )
}
