import { useNavigate } from 'react-router-dom';

function SettingsPage() {
  const navigate = useNavigate();

  return (
    <div className="fixed inset-0 bg-gradient-to-br from-pink-100 via-white to-red-50">
      {/* Fixed Header */}
      <div className="fixed top-0 left-0 right-0 z-10 flex items-center justify-between p-4 bg-gradient-to-r from-pink-50 to-red-50 shadow-sm">
        <div className="flex items-center gap-2">
          <button onClick={() => navigate(-1)} className="p-2 text-gray-700">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>
          <h1 className="text-2xl font-bold text-gray-700">Definições</h1>
        </div>
      </div>

      {/* Content - with padding to account for fixed header */}
      <div className="pt-20 pb-6 h-full overflow-y-auto">
        {/* Profile Settings Section */}
        <div className="mb-6">
          <h2 className="px-4 text-lg font-semibold text-gray-900 mb-2">Definições do Perfil</h2>
          <div className="bg-white/80 backdrop-blur-sm border border-gray-200 rounded-lg">
            <button className="w-full px-4 py-4 flex items-center justify-between border-b hover:bg-white/90 transition-all">
              <span className="text-gray-700">Mudar Nome</span>
              <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </button>
            <button className="w-full px-4 py-4 flex items-center justify-between border-b hover:bg-white/90 transition-all">
              <span className="text-gray-700">Mudar Senha</span>
              <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </button>
            <button className="w-full px-4 py-4 flex items-center justify-between border-b hover:bg-white/90 transition-all">
              <span className="text-gray-700">Adicionar Email</span>
              <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </button>
            <button className="w-full px-4 py-4 flex items-center justify-between hover:bg-white/90 transition-all">
              <span className="text-gray-700">Mudar Email</span>
              <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </button>
          </div>
        </div>

        {/* Privacy Settings Section */}
        <div className="mb-6">
          <h2 className="px-4 text-lg font-semibold text-gray-900 mb-2">Privacidade</h2>
          <div className="bg-white/80 backdrop-blur-sm border border-gray-200 rounded-lg">
            <button className="w-full px-4 py-4 flex items-center justify-between hover:bg-white/90 transition-all">
              <span className="text-gray-700">Bloquear Amigo</span>
              <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default SettingsPage;
