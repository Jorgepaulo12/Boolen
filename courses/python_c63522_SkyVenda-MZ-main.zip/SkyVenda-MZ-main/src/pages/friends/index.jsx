import React from 'react'

export default function Friends() {
  return (
    <div>friends</div>
  )
}
