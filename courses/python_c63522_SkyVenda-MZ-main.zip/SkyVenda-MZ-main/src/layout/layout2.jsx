import React from 'react';
import { Home, Search, Compass, Film, Heart, PlusSquare, MessageCircle, Menu, Instagram } from 'lucide-react';
import { useState } from 'react';
import { FaShopify } from 'react-icons/fa';
import { Link } from 'react-router-dom';

export default function Layout2({children}) {
  const [isOpen, setIsOpen] = useState(true);

  const menuItems = [
    { icon: <Home size={24} />, text: 'Página inicial', path: '/' },
    { icon: <Search size={24} />, text: 'Pesquisa', path: '/search' },
    { icon: <Compass size={24} />, text: 'Explorar', path: '/explore' },
    { icon: <Film size={24} />, text: 'Reels', path: '/reels' },
    { icon: <MessageCircle size={24} />, text: 'Mensagens', path: '/chat' },
    { icon: <Heart size={24} />, text: 'Notificações', path: '/notifications' },
    { icon: <PlusSquare size={24} />, text: 'Criar', path: '/create' },
  ];

  return (
    <div className='w-full min-h-screen bg-white flex'>
      {/* Sidebar */}
      <div className="w-[72px] lg:w-[244px] h-screen border-r border-gray-300 pt-2 px-3 fixed left-0 bg-white">
        {/* Logo */}
        <div className="pt-8 pb-6 mb-4">
          <div className="flex   gap-2 items-center text-indigo-500">
            <FaShopify className="w-8 h-8" />
            <h1 className='font-bold'>SkyVenda MZ</h1>
          </div>
        </div>

        {/* Menu Items */}
        <div className="flex flex-col gap-1">
          {menuItems.map((item, index) => (
            <Link
              key={index}
              to={item.path}
              className="flex items-center gap-4 p-3 hover:bg-gray-100 rounded-lg cursor-pointer transition-colors"
            >
              <div className="text-black">{item.icon}</div>
              <span className="hidden lg:block text-base font-normal">
                {item.text}
              </span>
            </Link>
          ))}
        </div>

        {/* Menu Button */}
        <div className="absolute bottom-5 w-[calc(100%-24px)]">
          <div className="flex items-center gap-4 p-3 hover:bg-gray-100 rounded-lg cursor-pointer transition-colors">
            <Menu size={24} />
            <span className="hidden lg:block text-base font-normal">Mais</span>
          </div>
        </div>
      </div>

      {/* Main Content Area with proper margin for sidebar */}
      <div className="ml-[72px] lg:ml-[244px] flex-1">
        {children}
      </div>
    </div>
  );
}