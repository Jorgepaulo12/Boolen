import axios from "axios";

const isDevelopment = window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1';

export const base_url = isDevelopment 
  ? 'http://localhost:8000'
  : 'https://skyvendamz-production.up.railway.app';

const api = axios.create({
    baseURL: base_url,
});

api.interceptors.request.use(config => {
    const token = localStorage.getItem('token');
    if (token) {
        config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
});

export default api;
