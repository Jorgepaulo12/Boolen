export default function SearchCard() {
 return (
    <div className="w-full flex  justify-center absolute pt-[65px]">
        <div className="absolute   h-[511px] w-[888px] rounded-lg bg-white shadow-xl border border-gray-100 py-2 animate-fadeIn z-50">
    
    </div>
    </div>
 );
}