export default function cardEdit() {
 return (
   <div className="bg-white rounded-lg shadow h-[calc(100vh-100px)]">
         <div className="p-4 border-b">
           <h2 className="text-lg font-semibold text-gray-900">Editar Produto</h2>
         </div>
         
       </div>
 );
}