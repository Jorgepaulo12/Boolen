import traceback
import sys
from pathlib import Path

arquivo = "teste.py"  # Nome do arquivo a ser executado

try:
    with open(arquivo, "r", encoding="utf-8") as f:
        codigo = f.read()

    # Configura o caminho do arquivo no sys.path
    sys.path.insert(0, str(Path(arquivo).parent))
    
    # Define um novo dicionário global para execução
    globals_dict = {
        '__file__': arquivo,
        '__name__': '__main__',
        '__package__': None,
    }
    
    # Compila e executa o código
    codigo_compilado = compile(codigo, arquivo, "exec")
    exec(codigo_compilado, globals_dict)

except Exception as e:
    # Captura o erro
    exc_type, exc_value, exc_traceback = sys.exc_info()
    
    # Remove as referências ao app.py do traceback
    while exc_traceback:
        if Path(exc_traceback.tb_frame.f_code.co_filename).name == arquivo:
            break
        exc_traceback = exc_traceback.tb_next

    # Imprime o erro formatado
    print(f"Erro no arquivo: {arquivo}")
    print(f"Tipo do erro: {type(e).__name__}")
    print(f"Detalhes: {str(e)}")
    print("\nTraceback completo:")
    
    # Imprime apenas o traceback relevante
    traceback.print_exception(exc_type, exc_value, exc_traceback)
