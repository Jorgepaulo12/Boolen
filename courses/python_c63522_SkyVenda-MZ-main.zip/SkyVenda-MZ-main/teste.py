print(1 / 1): # Erro de divisão por zero
ss